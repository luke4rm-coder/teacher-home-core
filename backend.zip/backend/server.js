require("dotenv").config();
const express = require("express");
const cors = require("cors");

const app = express();
const PORT = process.env.PORT || 4000;

// In-memory storage for demo; IT should replace with a real database
const submissions = [];

// In-memory questions store; teacher dashboard can update this.
let questions = [
  {
    text: "1) What is 2 + 2?",
    options: ["3", "4", "5", "6"],
    correctIndex: 1,
  },
  {
    text: "2) What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Rome"],
    correctIndex: 2,
  },
  {
    text: "3) What color do you get when you mix red and blue?",
    options: ["Green", "Purple", "Orange", "Yellow"],
    correctIndex: 1,
  },
  {
    text: "4) What is 5 × 3?",
    options: ["8", "10", "15", "20"],
    correctIndex: 2,
  },
  {
    text: "5) Which device is best for taking online quizzes?",
    options: ["Phone", "School Chromebook", "TV", "Game console"],
    correctIndex: 1,
  },
];

app.use(cors());
app.use(express.json());

// Health check
app.get("/", (req, res) => {
  res.json({ ok: true, message: "Quizlock backend running" });
});

// Students submit quiz results here
app.post("/submitQuiz", (req, res) => {
  const { studentName = "", score, totalQuestions, unlocked, timestamp } = req.body || {};

  if (typeof score !== "number" || typeof totalQuestions !== "number") {
    return res.status(400).json({ error: "score and totalQuestions must be numbers" });
  }

  const entry = {
    studentName: String(studentName).trim(),
    score,
    totalQuestions,
    unlocked: !!unlocked,
    timestamp: timestamp || Date.now(),
  };

  submissions.push(entry);
  console.log("New submission", entry);

  res.json({ ok: true });
});

// Teachers (or anyone with the URL) fetch stats here.
// NOTE: This endpoint is public – do not expose it on the open internet
// if you care about privacy.
app.get("/stats", (req, res) => {
  const sorted = submissions.slice().sort((a, b) => b.timestamp - a.timestamp);
  res.json(sorted);
});

// Students fetch current quiz questions here.
app.get("/questions", (req, res) => {
  res.json(questions);
});

// Teachers update the quiz questions here.
// Body: { questions: Array<{ text, options, correctIndex }> }
app.post("/questions", (req, res) => {
  const { questions: newQuestions } = req.body || {};

  if (!Array.isArray(newQuestions)) {
    return res.status(400).json({ error: "Field 'questions' must be an array" });
  }

  const sanitized = [];
  for (const q of newQuestions) {
    if (!q || typeof q.text !== "string" || !Array.isArray(q.options) || q.options.length < 2) {
      return res.status(400).json({ error: "Each question needs text and at least 2 options" });
    }
    const correctIndex = Number(q.correctIndex);
    if (!Number.isInteger(correctIndex) || correctIndex < 0 || correctIndex >= q.options.length) {
      return res.status(400).json({ error: "Each question needs a valid correctIndex" });
    }

    sanitized.push({
      text: String(q.text),
      options: q.options.map((opt) => String(opt)),
      correctIndex,
    });
  }

  questions = sanitized;
  console.log("Questions updated by teacher. Count:", questions.length);
  res.json({ ok: true, count: questions.length });
});

app.listen(PORT, () => {
  console.log(`Quizlock backend listening on port ${PORT}`);
});
